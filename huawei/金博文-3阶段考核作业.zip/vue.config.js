module.exports = {
    //部署应用包时的基本 URL 这里news是自己文件的名字
    publicPath: '/huawei',
};
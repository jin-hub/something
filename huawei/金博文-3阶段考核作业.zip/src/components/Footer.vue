<template>
	<div class="footer">
		<div class="foot-content">
			<div class="top">
				<div class="footer-copyright">
					<span>版权所有 © 金博文 2020</span>
					<span>保留一切权利</span>
					<span>
                        备案号
                    </span>
					<span>备案号</span>
					<span>代理域名注册服务机构</span>
				</div>
				<div class="footer-law">
                    <span>法律声明</span>
                    <span>|</span>
                    <span>隐私政策</span>
				</div>
			</div>
			<div class="footer-record">

			</div>
		</div>
	</div>
</template>

<script>
export default {}
</script>

<style>
.footer {
	width: 100%;
	background: #f3f3f3;
	height: 100px;
}
.footer .foot-content {
	color: rgba(37, 43, 58, 0.7);
	width: 1200px;
	margin: 0 auto;
	height: 100%;
	padding-top: 35px;
	line-height: 20px;
}
.footer-copyright {
	float: left;
}
.footer-low {
	float: right;
}
a {
	text-decoration: none;
	/* margin-left: 20px; */
}
.footer-copyright span {
	margin-left: 10px;
    margin-right: 10px;
}
.footer-law span{
	margin-left: 10px;
    margin-right: 10px;

}
</style>
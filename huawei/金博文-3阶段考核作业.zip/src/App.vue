<template>
  <div>
    <router-view/>
  </div>
</template>

<style>

</style>
